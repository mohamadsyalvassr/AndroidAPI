package local.percobaan.latihanjason;

public class koneksi {
    public String isi_koneksi() {
        String isi = "hhtp://192.168.0.132/projek_lar/public/api/";
        return isi;
    }
}

